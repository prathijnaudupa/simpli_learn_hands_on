package com.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.bean.Teacher;

public class AddTeachdao {
       public int addteach(int tid, String tname, int tage) {
    	   try {
 			  Configuration con = new Configuration();
 			  con.configure("hibernate.cfg.xml");
 			  SessionFactory sf = con.buildSessionFactory();
 			  Session session = sf.openSession();
 			  
 			  Transaction tran = session.getTransaction();
 			  tran.begin();
 			  Teacher t = new Teacher();
 			  t.setTeacher_id(tid);
 			  t.setTeacher_name(tname);
 			  t.setTeacher_age(tage);
 			  session.save(t);
 			  tran.commit();
 			  return 1;
 				}
 				catch(Exception e) {
 					System.out.println(e);
 					System.out.println(e.getMessage());
 					return 0;
 				}
       }
}
