package com.dao;

import java.io.PrintWriter;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.bean.Subject;

public class AssignClassdao {
	public int asgcls(int cid, int subid) {
	    Configuration con = new Configuration();
		con.configure("hibernate.cfg.xml");
		SessionFactory sf = con.buildSessionFactory();
		Session session = sf.openSession();
		Transaction tran = session.getTransaction();
	    Subject s1 = session.get(Subject.class, subid);
		if(s1==null) {
			System.out.println("Subject not present");
			return 0;
		}else {
			tran.begin();
			s1.setClass_subjectid(cid);
			session.update(s1);
			tran.commit();
			System.out.println("Assigned class for subject");
			return 1;

	}
}

}
