package com.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.AddStuddao;

/**
 * Servlet implementation class addstudentCon
 */
public class addstudentCon extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public addstudentCon() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		PrintWriter pw = response.getWriter();
		int student_id = Integer.parseInt(request.getParameter("student_id"));
		String student_name = request.getParameter("student_name");
		int student_age = Integer.parseInt(request.getParameter("student_age"));
		response.setContentType("text/html");
	
		HttpSession hs = request.getSession();
		RequestDispatcher rd = request.getRequestDispatcher("addstud.jsp");
		
		AddStuddao asd = new AddStuddao();
		int a = asd.addstud(student_id, student_name, student_age);
		if(a==1) {
			pw.println("Student data added successfully!!!");
			rd.include(request, response);
			
		}
		else {
			pw.println("Student details not added!!");
			rd.include(request, response);
		}
		
			
	}

}
