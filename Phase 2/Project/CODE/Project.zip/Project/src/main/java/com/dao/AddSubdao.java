package com.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.bean.Subject;


public class AddSubdao {
      public int addsub(int sid, String sname, int scrd) {
    	  try {
 			  Configuration con = new Configuration();
 			  con.configure("hibernate.cfg.xml");
 			  SessionFactory sf = con.buildSessionFactory();
 			  Session session = sf.openSession();
 			  
 			  Transaction tran = session.getTransaction();
 			  tran.begin();
 			  Subject s = new Subject();
 			  s.setSubject_id(sid);
 			  s.setSubject_name(sname);
 			  s.setSubject_credits(scrd);
 			  session.save(s);
 			  tran.commit();
 			  return 1;
 				}
 				catch(Exception e) {
 					System.out.println(e);
 					System.out.println(e.getMessage());
 					return 0;
 				}
      }
}
