package com.bean;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;


@Entity
public class Sclass {
	 @Id
     private int class_id;
     private String class_name;
     @OneToMany
     @JoinColumn(name = "class_subjectid")
     private List<Subject> listOfSub;
     private Integer teacher_classid;
     @OneToMany
 	 @JoinColumn(name = "class_studentid")
     private List<Students> listOfStud;
	public int getClass_id() {
		return class_id;
	}
	public void setClass_id(int class_id) {
		this.class_id = class_id;
	}
	public String getClass_name() {
		return class_name;
	}
	public void setClass_name(String class_name) {
		this.class_name = class_name;
	}
	public List<Subject> getListOfSub() {
		return listOfSub;
	}
	public void setListOfSub(List<Subject> listOfSub) {
		this.listOfSub = listOfSub;
	}
	public Integer getTeacher_classid() {
		return teacher_classid;
	}
	public void setTeacher_classid(Integer teacher_classid) {
		this.teacher_classid = teacher_classid;
	}
	public List<Students> getListOfStud() {
		return listOfStud;
	}
	public void setListOfStud(List<Students> listOfStud) {
		this.listOfStud = listOfStud;
	}
	@Override
	public String toString() {
		return "Class [class_id=" + class_id + ", class_name=" + class_name + ", listOfSub=" + listOfSub
				+ ", teacher_classid=" + teacher_classid + ", listOfStud=" + listOfStud + "]";
	}

}
