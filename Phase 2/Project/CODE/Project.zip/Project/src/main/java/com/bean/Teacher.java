package com.bean;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

@Entity
public class Teacher {
    @Id
	private int teacher_id;
	private String teacher_name;
	private int teacher_age;
	 @OneToMany
     @JoinColumn(name = "teacher_classid")
     private List<Sclass> listOfClass;
	public int getTeacher_id() {
		return teacher_id;
	}
	public void setTeacher_id(int teacher_id) {
		this.teacher_id = teacher_id;
	}
	public String getTeacher_name() {
		return teacher_name;
	}
	public void setTeacher_name(String teacher_name) {
		this.teacher_name = teacher_name;
	}
	public int getTeacher_age() {
		return teacher_age;
	}
	public void setTeacher_age(int teacher_age) {
		this.teacher_age = teacher_age;
	}
	public List<Sclass> getListOfClass() {
		return listOfClass;
	}
	public void setListOfClass(List<Sclass> listOfClass) {
		this.listOfClass = listOfClass;
	}
	@Override
	public String toString() {
		return "Teacher [teacher_id=" + teacher_id + ", teacher_name=" + teacher_name + ", teacher_age=" + teacher_age
				+ ", listOfClass=" + listOfClass + "]";
	}
}
