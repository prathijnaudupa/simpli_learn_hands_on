package com.bean;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Subject {
	@Id
	private int subject_id;
	private String subject_name;
	private int subject_credits;
	private Integer class_subjectid;
	public int getSubject_id() {
		return subject_id;
	}
	public void setSubject_id(int subject_id) {
		this.subject_id = subject_id;
	}
	public String getSubject_name() {
		return subject_name;
	}
	public void setSubject_name(String subject_name) {
		this.subject_name = subject_name;
	}
	public int getSubject_credits() {
		return subject_credits;
	}
	public void setSubject_credits(int subject_credits) {
		this.subject_credits = subject_credits;
	}
	public Integer getClass_subjectid() {
		return class_subjectid;
	}
	public void setClass_subjectid(Integer class_subjectid) {
		this.class_subjectid = class_subjectid;
	}
	@Override
	public String toString() {
		return "Subject [subject_id=" + subject_id + ", subject_name=" + subject_name + ", subject_credits="
				+ subject_credits + ", class_subjectid=" + class_subjectid + "]";
	}
	
}