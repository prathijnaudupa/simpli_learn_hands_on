package com.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.AddClassdao;

/**
 * Servlet implementation class addclassCon
 */
public class addclassCon extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public addclassCon() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		PrintWriter pw = response.getWriter();
		int class_id = Integer.parseInt(request.getParameter("class_id"));
		String class_name = request.getParameter("class_name");
		response.setContentType("text/html");
	
		HttpSession hs = request.getSession();
		RequestDispatcher rd = request.getRequestDispatcher("addclass.jsp");
		AddClassdao acd = new AddClassdao();
		int a = acd.addcls(class_id, class_name);
		if(a==1) {
			pw.println("Class data added successfully!!!");
			rd.include(request, response);
			
		}
		else {
			pw.println("Class details not added!!");
			rd.include(request, response);
		}
	}

}
