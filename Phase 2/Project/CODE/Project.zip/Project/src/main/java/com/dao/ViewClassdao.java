package com.dao;

import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.bean.Sclass;
import com.bean.Students;
import com.bean.Subject;
import com.bean.Teacher;


public class ViewClassdao {
	 public List<Sclass> cls() {
		 Configuration con = new Configuration();
		 con.configure("hibernate.cfg.xml");
		 SessionFactory sf =  con.buildSessionFactory();
		 Session session = sf.openSession();
		 TypedQuery qry = session.createQuery("select c from Sclass c");
		 List<Sclass> listOfClass = qry.getResultList();
	     return listOfClass;
	 }
	 
	 public List<Students> stud(){
		 Configuration con = new Configuration();
		 con.configure("hibernate.cfg.xml");
		 SessionFactory sf =  con.buildSessionFactory();
		 Session session = sf.openSession();
		 TypedQuery qst = session.createQuery("select st from Students st");
		 List<Students> listOfStudents = qst.getResultList();
	     return listOfStudents;
		 
	 }
	 public List<Subject> sub(){
		 Configuration con = new Configuration();
		 con.configure("hibernate.cfg.xml");
		 SessionFactory sf =  con.buildSessionFactory();
		 Session session = sf.openSession();
		 TypedQuery qsub = session.createQuery("select s from Subject s");
		 List<Subject> listOfSubject = qsub.getResultList();
	     return listOfSubject;
		 
	 }
	 public List<Teacher> teach(){
		 Configuration con = new Configuration();
		 con.configure("hibernate.cfg.xml");
		 SessionFactory sf =  con.buildSessionFactory();
		 Session session = sf.openSession();
		 TypedQuery qteach = session.createQuery("select t from Teacher t");
		 List<Teacher> listOfTeacher = qteach.getResultList();
	     return listOfTeacher;
		 
	 }
}
