package com.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.AssignTeachdao;
import com.service.assignteachService;

/**
 * Servlet implementation class assignteachCon
 */
public class assignteachCon extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public assignteachCon() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		PrintWriter pw = response.getWriter();
		int cls_id = Integer.parseInt(request.getParameter("cls_id"));
		int teach_id = Integer.parseInt(request.getParameter("teach_id"));
		response.setContentType("text/html");
		
		HttpSession hs = request.getSession();
		RequestDispatcher rd = request.getRequestDispatcher("assignteach.jsp");
		assignteachService ats = new assignteachService();
		int c = ats.checkclsid(cls_id);
		int t = ats.checkteachid(teach_id);
		if(c==1 && t==1) {
			AssignTeachdao atd = new AssignTeachdao();
			int a = atd.asgtch(teach_id,cls_id);
			if(a==1) {
				pw.println("Successfully assigned teacher to the class!!");
				rd.include(request, response);
			}else {
				pw.println("Sorry!!! failed to assign..");
				rd.include(request, response);
			}
			
		}
		else if(c==0) {
			pw.println("Sorry!!! Class  id is not available, please give valid class id..");
			rd.include(request, response);
		}
		else {
			pw.println("Sorry!!! Teacher id is not available, please give valid teacher id..");
			rd.include(request, response);
		}
		
	}

}
