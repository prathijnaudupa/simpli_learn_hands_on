package com.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.AddSubdao;

/**
 * Servlet implementation class addsubjectCon
 */
public class addsubjectCon extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public addsubjectCon() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		PrintWriter pw = response.getWriter();
		int subject_id = Integer.parseInt(request.getParameter("subject_id"));
		String subject_name = request.getParameter("subject_name");
		int subject_credits = Integer.parseInt(request.getParameter("subject_credits"));
		response.setContentType("text/html");
	
		HttpSession hs = request.getSession();
		RequestDispatcher rd = request.getRequestDispatcher("addsub.jsp");
		AddSubdao asd = new AddSubdao();
		int a = asd.addsub(subject_id, subject_name, subject_credits);
		if(a==1) {
			pw.println("Subject data added successfully!!!");
			rd.include(request, response);
			
		}
		else {
			pw.println("Subject details not added!!");
			rd.include(request, response);
		}
	}

}
