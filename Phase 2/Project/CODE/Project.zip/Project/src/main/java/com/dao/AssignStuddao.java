package com.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.bean.Students;



public class AssignStuddao {
      public int asgstud(int cid, int sid) {
    	  Configuration con = new Configuration();
  		con.configure("hibernate.cfg.xml");
  		SessionFactory sf = con.buildSessionFactory();
  		Session session = sf.openSession();
  		Transaction tran = session.getTransaction();
  	    Students s1 = session.get(Students.class, sid);
  		if(s1==null) {
  			System.out.println("Student not present");
  			return 0;
  		}else {
  			tran.begin();
  			s1.setClass_studentid(cid);
  			session.update(s1);
  			tran.commit();
  			System.out.println("Assigned student to class");
  			return 1;
      }
}
}
