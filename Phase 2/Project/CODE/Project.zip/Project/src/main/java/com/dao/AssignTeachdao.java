package com.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.bean.Sclass;



public class AssignTeachdao {
   public int asgtch(int tid, int cid) {
	   Configuration con = new Configuration();
		con.configure("hibernate.cfg.xml");
		SessionFactory sf = con.buildSessionFactory();
		Session session = sf.openSession();
		Transaction tran = session.getTransaction();
	    Sclass s1 = session.get(Sclass.class, cid);
	    if(s1==null) {
			System.out.println("Class not present");
			return 0;
		}else {
			tran.begin();
			s1.setTeacher_classid(tid);
			session.update(s1);
			tran.commit();
			System.out.println("Assigned teacher for class");
			return 1;

	}
}
   }

