package com.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.AssignStuddao;
import com.service.assignstudService;

/**
 * Servlet implementation class assignstudCon
 */
public class assignstudCon extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public assignstudCon() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		PrintWriter pw = response.getWriter();
		int cls_id = Integer.parseInt(request.getParameter("cls_id"));
		int stud_id = Integer.parseInt(request.getParameter("stud_id"));
		response.setContentType("text/html");
		
		HttpSession hs = request.getSession();
		RequestDispatcher rd = request.getRequestDispatcher("assignstud.jsp");
		assignstudService as = new assignstudService();
		int c = as.checkclsid(cls_id);
		int s = as.checkstudid(stud_id);
		if(c==1 && s==1) {
			AssignStuddao adds = new AssignStuddao();
			int a = adds.asgstud(cls_id, stud_id);
			if(a==1) {
				pw.println("Successfully assigned student to class!!");
				rd.include(request, response);
			}else {
				pw.println("Sorry!!!, failed to assign..");
				rd.include(request, response);
			}
			
		}else if(c==0) {
			pw.println("Sorry!!! Class  id is not available, please give valid class id..");
			rd.include(request, response);
		}else {
			pw.println("Sorry!!! Student id is not available, please give valid student id..");
			rd.include(request, response);
		}
	}

}
