package com.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.AddTeachdao;

/**
 * Servlet implementation class addteacherCon
 */
public class addteacherCon extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public addteacherCon() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	//	response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		PrintWriter pw = response.getWriter();
		int teacher_id = Integer.parseInt(request.getParameter("teacher_id"));
		String teacher_name = request.getParameter("teacher_name");
		int teacher_age = Integer.parseInt(request.getParameter("teacher_age"));
		response.setContentType("text/html");
	
		HttpSession hs = request.getSession();
		RequestDispatcher rd = request.getRequestDispatcher("addteach.jsp");
		
		AddTeachdao atd = new AddTeachdao();
		int a = atd.addteach(teacher_id, teacher_name, teacher_age);
		if(a==1) {
			pw.println("Teacher data added successfully!!!");
			rd.include(request, response);
			
		}
		else {
			pw.println("Teacher details not added!!");
			rd.include(request, response);
		}
	}

}
