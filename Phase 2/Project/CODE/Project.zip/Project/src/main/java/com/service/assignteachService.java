package com.service;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

public class assignteachService {

	  public int checkclsid(int clsid) {
		   ArrayList<Integer> al1 = new ArrayList<Integer>();
		   Configuration con = new Configuration();
		   con.configure("hibernate.cfg.xml");
		   SessionFactory sf = con.buildSessionFactory();
		   Session session = sf.openSession();
		   Query query = session.createQuery("select c.class_id from Sclass c");
		   List<Object[]> rows = query.list();
		   for(Object r : rows) {
			   al1.add((Integer) r);
			   
		   }
		   if(al1.contains(clsid)) {
			   return 1;
		   }else {
			   return 0;
		   }
		   
	}
	  public int checkteachid(int tid) {
		  ArrayList<Integer> al = new ArrayList<Integer>();
		   Configuration con = new Configuration();
		   con.configure("hibernate.cfg.xml");
		   SessionFactory sf = con.buildSessionFactory();
		   Session session = sf.openSession();
		   Query query = session.createQuery("select t. teacher_id from Teacher t");
		   List<Object[]> rows = query.list();
		   for(Object r : rows) {
			   al.add((Integer) r);
		   }
		   if(al.contains(tid)) {
			   return 1;
		   }else {
			   return 0;
		   }
	  }
}
