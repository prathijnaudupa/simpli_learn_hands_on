package com.controller;

import java.io.IOException;

import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import com.bean.Sclass;
import com.bean.Students;
import com.bean.Subject;
import com.bean.Teacher;
import com.dao.ViewClassdao;


/**
 * Servlet implementation class viewclassCon
 */
public class viewclassCon extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public viewclassCon() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		PrintWriter pw = response.getWriter();
		
		int psd= Integer.parseInt(request.getParameter("psd"));
		response.setContentType("text/html");
	
		HttpSession hs = request.getSession();
	    RequestDispatcher rd = request.getRequestDispatcher("viewclass.jsp");
	 
	 
		if(psd==123) {
			  ViewClassdao vcd = new ViewClassdao();
			  List<Sclass> loc = vcd.cls();
			  pw.println("<h2 style=\"text-align: center;\">Teachers assigned to Classes</h2>");
				pw.write("<table  style=\"margin: 0px auto;\"border=2>");
				pw.println("<tr> <th>Class Id</th>  <th>Class Name</th> <th>Teacher's Id</th>");
				Iterator<Sclass> li = loc.iterator();
				while(li.hasNext()) {
					Sclass p = li.next();
					pw.println("<tr><td>"+p.getClass_id()+"</td><td>"+p.getClass_name()+"</td><td>"+p.getTeacher_classid()+"</td></tr>");
					
				}
				pw.println("</table>");
				pw.println("<br/>");
				pw.println("<hr/>");
				  List<Students> lost = vcd.stud();
				  pw.println("<h2 style=\"text-align: center;\">Class assigned to Students</h2>");
					pw.write("<table  style=\"margin: 0px auto;\"border=2>");
					pw.println("<tr> <th>Student Id</th>  <th>Class Id</th> <th>Student Age</th> <th>Student Name</th>");
					Iterator<Students> lst = lost.iterator();
					while(lst.hasNext()) {
						Students pp = lst.next();
						pw.println("<tr><td>"+pp.getStudent_id()+"</td><td>"+pp.getClass_studentid()+"</td><td>"+pp.getStudent_age()+"</td><td>"+pp.getStudent_name()+"</td></tr>");
						
					}
					pw.println("</table>");
					pw.println("<br/>");
					pw.println("<hr/>");
					  List<Subject> los = vcd.sub();
					  pw.println("<h2 style=\"text-align: center;\">Classes assgined for Subjects</h2>");
						pw.write("<table  style=\"margin: 0px auto;\"border=2>");
						pw.println("<tr> <th>Subject Id</th>  <th>Class_Subjectid</th> <th>Subject Credits</th> <th>Subject Name</th>");
						Iterator<Subject> ls = los.iterator();
						while(ls.hasNext()) {
							Subject ppp = ls.next();
							pw.println("<tr><td>"+ppp.getSubject_id()+"</td><td>"+ppp.getClass_subjectid()+"</td><td>"+ppp.getSubject_credits()+"</td><td>"+ppp.getSubject_name()+"</td></tr>");
							
						}
						pw.println("</table>");
						pw.println("<br/>");
						 List<Teacher> lt = vcd.teach();
							pw.println("<h2 style=\"text-align: center;\">Teacher Details</h2>");
							pw.write("<table  style=\"margin: 0px auto;\"border=2>");
							pw.println("<tr> <th>Teacher Id</th>  <th>Teacher Age</th> <th>Teacher Name</th>");
							Iterator<Teacher> ltt = lt.iterator();
							while(ltt.hasNext()) {
								Teacher h = ltt.next();
								pw.println("<tr><td>"+h.getTeacher_id()+"</td><td>"+h.getTeacher_age()+"</td><td>"+h.getTeacher_name()+"</td></tr>");
								
							}
							pw.println("</table>");
							pw.println("<br/>");
				            pw.println("<a href='home.jsp'><h3 style=\"text-align: center;\">Home</h3></a>");
		}else {
			pw.println("Sorry!!! Wrong Password try again..");
		rd.include(request, response);
		}
	}

}
