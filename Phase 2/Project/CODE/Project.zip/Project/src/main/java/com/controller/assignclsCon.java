package com.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.AssignClassdao;
import com.service.assignclsService;

/**
 * Servlet implementation class assignclsCon
 */
public class assignclsCon extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public assignclsCon() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		PrintWriter pw = response.getWriter();
		int sub_id = Integer.parseInt(request.getParameter("sub_id"));
		int cls_id = Integer.parseInt(request.getParameter("cls_id"));
		response.setContentType("text/html");
		
		HttpSession hs = request.getSession();
		RequestDispatcher rd = request.getRequestDispatcher("assigncls.jsp");
		assignclsService ac = new assignclsService();
		int s = ac.checksubid(sub_id);
		int c = ac.checkclsid(cls_id);
		if(s==1 && c==1) {
			AssignClassdao acd = new AssignClassdao();
			int a = acd.asgcls(cls_id, sub_id);
			if(a==1) {
				pw.println("Successfully assigned class for the subject!!");
				rd.include(request, response);
			}else {
				pw.println("Sorry!!! failed to assign");
				rd.include(request, response);
			}
			
			
		}else if(s==0) {
			pw.println("Sorry!!! Subject id is not available, please give valid subject id..");
			rd.include(request, response);
		}else {
			pw.println("Sorry!!! Class id is not available, please give valid class id");
			rd.include(request, response);
		}
		
	}

}
