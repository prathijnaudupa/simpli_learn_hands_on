package com.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.bean.Sclass;


public class AddClassdao {
      public int addcls(int cid, String cname) {
    	  try {
 			  Configuration con = new Configuration();
 			  con.configure("hibernate.cfg.xml");
 			  SessionFactory sf = con.buildSessionFactory();
 			  Session session = sf.openSession();
 			  
 			  Transaction tran = session.getTransaction();
 			  tran.begin();
 			  Sclass sc = new Sclass();
 			  sc.setClass_id(cid);
 			  sc.setClass_name(cname);
 			  
 			  session.save(sc);
 			  tran.commit();
 			  return 1;
 				}
 				catch(Exception e) {
 					System.out.println(e);
 					System.out.println(e.getMessage());
 					return 0;
 				}
      }
}
