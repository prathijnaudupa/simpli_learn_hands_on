package com.service;

import com.bean.Products;
import com.dao.Productsdao;

public class ProductService {

	Productsdao pd = new Productsdao();
	public String storeProduct(Products product) {
		if(product.getPrice()<100) {
			return "Product price must be > 100";
		}else if(pd.storeProduct(product)>0){
			return "Product stored successfully!!";
		}else {
			return "Product didn't store id must be unique";
		}
}
}
